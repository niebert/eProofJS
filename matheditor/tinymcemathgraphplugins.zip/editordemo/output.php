<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7, IE=9" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
<script type="text/javascript" src="jscripts/tiny_mce/plugins/asciimath/js/ASCIIMathMLwFallback.js"></script>
<script type="text/javascript" src="jscripts/tiny_mce/plugins/asciisvg/js/ASCIIsvg.js"></script>
<script type="text/javascript">
var AScgiloc = 'http://www.imathas.com/editordemo/php/svgimg.php';
var AMTcgiloc = "http://www.imathas.com/cgi-bin/mimetex.cgi";
</script>
<style type="text/css">
svg {
	overflow: hidden;
}
</style>

</head>
<body>
<?php

//This file is used for testing purposes - to display the output of the 
//editor
echo stripslashes($_POST['elm1']);
?>
</body>
</html>