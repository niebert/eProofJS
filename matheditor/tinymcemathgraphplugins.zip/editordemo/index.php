<?php
header("location: http://www.imathas.com/editordemo/demo.html");
?>